package com.pp.jdbc.ui;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Scanner;

import com.pp.jdbc.bean.BankAccount;
import com.pp.jdbc.service.BankService;

public class InputOutputClass {

	Scanner scanner = new Scanner(System.in);
	BankAccount bankObj = new BankAccount();
	BankService service = new BankService();

	public void display() {
		int i=1000;
		do {
			System.out.println("*****************");
			System.out.println("ABSRK Bank");
			System.out.println("*****************");
			
			
			System.out.print("1) Create Account" + "\n" + "2) Show Balance" + "\n" + "3) Cash Deposit" + "\n"
					+ "4) Cash Withdrawl" + "\n" + "5. Cash Transfer" + "\n" + "6. Show Transactions" + "\n" + "7. Exit"
					+ "\n" + "Enter Your Choice: ");
			switch (scanner.nextInt()) {
			case 1: {
				System.out.print("Enter Name: ");
				bankObj.setName(scanner.next());
				bankObj.setAccountNumber(i++);
				System.out.println("Your Account Number is: " + bankObj.getAccountNumber());
				System.out.print("Enter your first Deposit: ");
				bankObj.setBalance(scanner.nextDouble());
				System.out.print("Enter your age: ");
				bankObj.setAge(scanner.nextInt());
				System.out.println(service.createAcccount(bankObj));
			}
				break;
			case 2: {
				System.out.print("Enter Your Account Number: ");
				System.out.println("Your Account Balance is: " + service.showBalance(scanner.nextInt()));

			}
				break;
			case 3: {
				System.out.print("Enter Your Account Number: ");
				int accountNumber = scanner.nextInt();
				System.out.print("Enter the amount you want to deposit: ");
				double credit = scanner.nextInt();
				System.out.println(service.deposit(accountNumber, credit));
			}
				break;
			case 4: {
				System.out.print("Enter Account Number: ");
				int accountNumber = scanner.nextInt();
				System.out.print("Enter the amount you want to withdraw: ");
				double debit = scanner.nextInt();
				System.out.println(service.withdraw(accountNumber, debit));
			}
				break;
			case 5: {
				System.out.print("Enter Your Account Number: ");
				int senderAccountNumber = scanner.nextInt();
				System.out.print("Enter Receiver Account Number: ");
				int receiverAccountNumber = scanner.nextInt();
				System.out.print("Enter the amount you want to transfer: ");
				double transferAmount = scanner.nextInt();
				System.out.println(service.cashTransfer(senderAccountNumber, receiverAccountNumber, transferAmount));
			}
				break;
			case 6: {
				System.out.print("Enter Account Number: ");
				int accountNumber = scanner.nextInt();
				ResultSet resultList = service.getTransactions(accountNumber);
				System.out.println("Transaction List: ");
				try {
					while (resultList.next()) {

						System.out.println("accountNumber=" + resultList.getInt("account_number") + ", credit="
								+ resultList.getDouble("credit") + ", debit=" + resultList.getDouble("debit")
								+ ", amount=" + resultList.getDouble("amount"));
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
				break;
			case 7:
				System.out.println("Exited....");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Choose the given options and try again:");
				break;
			}
		} while (true);
	}

}
