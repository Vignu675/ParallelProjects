package com.pp.jdbc.service;

import java.sql.ResultSet;


import com.pp.jdbc.bean.BankAccount;

import com.pp.jdbc.dao.BankDao;

public class BankService{
	
	BankDao daoObj=new BankDao();


	public String createAcccount(BankAccount bObj) {
		if(daoObj.createAccount(bObj))
			return "Account Created";
		else
			return "Enter Correct Details";
	}


	public double showBalance(int accountNumber) {
		return daoObj.getBalance(accountNumber);
	}


	public String deposit(int accountNumber, double credit) {
		if(daoObj.depositAmount(accountNumber,credit))
			return "Balance added";
		else
			return "Enter Correct Details";
	}


	public String withdraw(int accountNumber, double debit) {
		if(daoObj.withdrawAmount(accountNumber,debit))
			return "Balance deducted";
		else
			return "Enter Correct Details";
	}


	public String cashTransfer(int senderAccountNumber, int receiverAccountNumber, double transferAmount) {
		if(withdraw(senderAccountNumber, transferAmount).startsWith("B") && deposit(receiverAccountNumber, transferAmount).startsWith("B"))
			return "Transaction Successfull";
		else
			return "Enter Correct Details";
	}


	public ResultSet getTransactions(int accountNumber) {
		
		return daoObj.getAllTransactions(accountNumber);
	}


}
