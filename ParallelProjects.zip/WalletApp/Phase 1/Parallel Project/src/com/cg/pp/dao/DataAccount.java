package com.cg.pp.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.pp.bean.AccountDetails;
import com.cg.pp.bean.TransactionDetails;

public class DataAccount {
	List<AccountDetails> accountList = new ArrayList<>();
	List<TransactionDetails> transactionList = new ArrayList<>();

	public void setAccountList(AccountDetails account) {
		
		accountList.add(account);

	}

	public void setTransactionList(TransactionDetails transaction) {
		
		transactionList.add(transaction);
	
	}

	public List<AccountDetails> getAccountList() {

		return accountList;

	}

	public List<TransactionDetails> getTransactionList() {
	
		return transactionList;
	
	}

}
