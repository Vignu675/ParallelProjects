package com.cg.pp.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.pp.bean.AccountDetails;
import com.cg.pp.bean.TransactionDetails;
import com.cg.pp.service.ServiceAccount;


public class Main {
	 static Scanner scanner = new Scanner(System.in);	
	 static ServiceAccount service = new ServiceAccount();
	public static void main(String[] args) {
		int i=1000;
		for (;;) {
			
			System.out.println("*****************");
			System.out.println("ABSRK Bank");
			System.out.println("*****************");
			System.out.print(
					"1. Create Account\n"
					+ "2. Show Balance\n"
					+ "3. Deposit\n"
					+ "4. Withdraw\n"
					+ "5. Fund Transfer\n"
					+ "6. Print Transactions\n"
					+ "7. Exit\n"
					+ "Enter Your Choice: ");
			switch (scanner.nextInt()) {
			case 1: {
				AccountDetails account = new AccountDetails();
				System.out.print("Enter your Name: ");
				account.setName(scanner.next());
				account.setAccountNumber(i++);
				System.out.println("Your Account Number is: " + account.getAccountNumber());
				System.out.print("Enter your first Deposit: ");
				account.setAmount(scanner.nextDouble());
				service.createAccount(account);

			}
				break;
			case 2: {
				System.out.print("Enter Your Account Number: ");
				System.out.println("Your Account Balance is: " + service.showBalance(validateAccountNumber()));
			}
				break;
			case 3: {
				System.out.print("Enter Your Account Number: ");
				int accountNumber = validateAccountNumber();
				System.out.print("Enter the amount you want to deposit: ");
				double credit = scanner.nextInt();
				System.out.println("Balance credited to account: " + accountNumber + "\nCredited: " + credit
						+ "\nAvailable balance is: " + service.deposit(accountNumber, credit));
			}
				break;
			case 4: {
				System.out.print("Enter Account Number: ");
				int accountNumber = validateAccountNumber();
				System.out.print("Enter the amount you want to withdraw: ");
				double debit=0;
				while(true) {
					debit=scanner.nextInt();
					if(service.withdraw(accountNumber, debit)!=-1)
						break;
					System.out.println("Insuffient funds. Enter again: ");
				}
				System.out.println("Balance debited from account: " + accountNumber + "\nDebited: " + debit
						+ "\nAvailable balance is: " + service.showBalance(accountNumber));
			}
				break;
			case 5: {
				System.out.print("Enter Your Account Number: ");
				int senderAccountNumber = validateAccountNumber();
				System.out.print("Enter Receiver Account Number: ");
				int receiverAccountNumber = validateAccountNumber();
				System.out.print("Enter the amount you want to transfer: ");
				double transferAmount = 0;
				while(true) {
					transferAmount=scanner.nextInt();
					if(service.fundTransfer(senderAccountNumber, receiverAccountNumber, transferAmount)!=-1)
						break;
					System.out.println("Insuffient funds. Enter again: ");
				}
				System.out.println("Balance debited from account: " + senderAccountNumber + " is " + transferAmount
						+ "\nBalance credited to account: " + receiverAccountNumber + "\nAvailable balance is: "
						+ service.showBalance(senderAccountNumber));
			}
				break;
			case 6: {
				System.out.print("Enter Account Number: ");
				int accountNumber = validateAccountNumber();
				List<TransactionDetails> resultList = service.getTransactionDetails(accountNumber);
				System.out.println("Transaction List: ");
				for (TransactionDetails transactionDetails : resultList)
					System.out.println(transactionDetails);
			}
				break;
			case 7:
				System.out.println("Exited....");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice..Try again");
				break;
			}
		}
		
	}
	
	public static int validateAccountNumber() {
		int accountNumber=0;
		while(true) {
		accountNumber=scanner.nextInt();
		if(service.validateAccountNumber(accountNumber))
			return accountNumber;
		else {
		System.out.println("Account Number Doesn't Exist. Enter Account Number Again: ");
		}
		}
	}
}
