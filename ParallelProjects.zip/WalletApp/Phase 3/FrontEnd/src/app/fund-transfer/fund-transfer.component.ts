import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  customer: Customer;
  message: string;
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }
  fundTransfer(senderAccountNumber: number, recieverAccNumber: number, amount: number) {
    if (senderAccountNumber && recieverAccNumber && amount) {
      this.customer = new Customer('', '', 0, '', amount);
      this.customerService.fundTransfer(senderAccountNumber, recieverAccNumber, this.customer).subscribe(data => {
        this.message = 'Hello ' + data.fName + ' ' + data.lName + ', your Remaining Available is ' + data.amount;
      }, (err) => alert('Enter valid Account Number'));
    } else {
      alert('Enter Account Details!');
    }
  }

}
