import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  customer: Customer;
  message: string;
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
  }
  depositAmount(accountNumber: number, amount: number) {
    if (accountNumber && amount) {
      this.customer = new Customer('', '', 0, '', amount);
      this.customerService.depositAmount(accountNumber, this.customer).subscribe(data => {
        this.message = 'Hello ' + data.fName + ' ' + data.lName + ', your Current Balance is ' + data.amount;
      }, (err) => alert('Enter valid Account Number'));
    } else {
      alert('Enter Account Details!');
    }

  }

}
